package edu.upenn.cis.cis121.project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;


public class DBWrapper {
	public enum TableName {USER, PLACE}
	
	private HashMap<Integer, User> _users; // Store queried objects locally
	private HashMap<Integer, Place> _places;
	
	private Connection _conn;
	private String _dbUser;
	private String _dbPass;
	private String _dbSID;
	private String _dbHost;
	private int _port;
	
	/**
	 * Default constructor
	 * the parameters here are the same as for the PopulateDB constructor
	 */ 
	public DBWrapper(String dbUser, String dbPass, String dbSID, String dbHost, int port) {
		_users = new HashMap<Integer, User>();
		_places = new HashMap<Integer, Place>();
		
		_dbUser = dbUser;
		_dbPass = dbPass;
		_dbSID = dbSID;
		_dbHost = dbHost;
		_port = port;
		
		populateUsers();
		System.out.println(_users.size());
		populatePlaces();
	}
	
	/**
	 * Helper method that scrapes User table rows and stores in a HashMap
	 */
	private void populateUsers() {
		String query = "select * from Users";
		
		try {
			String res = this.openDBConnection();
			System.out.println(res);
			Statement st = _conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			while (rs.next()) {
				User user = new User(rs);
				_users.put(user._id, user);
			}

			rs.close();
			st.close();
		} catch (SQLException s) {
			System.err.println("Registrar encountered an exception: " + s.toString());
		} catch (ClassNotFoundException c) {
			System.err.println("Registrar encountered an exception: " + c.toString());
		} finally {
			this.closeDBConnection();
		}
	}
	
	/**
	 * Helper method that scrapes User table rows and stores in a HashMap
	 */
	private void populatePlaces() {
		String query = "select * from Places";

		try {
			String res = this.openDBConnection();
			System.out.println(res);
			Statement st = _conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			while (rs.next()) {
				Place place = new Place(rs);
				_places.put(place._id, place);
				}

			rs.close();
			st.close();
		} catch (SQLException s) {
			System.err.println("Registrar encountered an exception: " + s.toString());
		} catch (ClassNotFoundException c) {
			System.err.println("Registrar encountered an exception: " + c.toString());
		} finally {
			this.closeDBConnection();
		}
	}
	
	/**
	 * Open the database connection.
	 * 
	 * @param dbUser
	 * @param dbPass
	 * @param dbSID
	 * @param dbHost
	 * @param port
	 * @return status (string)
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	private String openDBConnection() throws SQLException, ClassNotFoundException{
		
		_conn = DBUtils.openDBConnection(_dbUser, _dbPass, _dbSID, _dbHost, _port);
		String res = DBUtils.testConnection();
	
		return res;
	}
	
	/**
	 * Close the database connection.
	 * @throws SQLException
	 */
	private void closeDBConnection() {
		try {
			DBUtils.closeDBConnection();
		} catch (SQLException sqle) {
			sqle.printStackTrace(System.err);
		}
	}
	
	
	/**
	 * returns the user_ids of all friends of the user with the input user_id, 
	 * null if no friends or user not in db
	 * @param user_id
	 * @return
	 */
	public int[] getFriends(int user_id) {
		
		User user = _users.get(user_id);
		if (user == null) {
			return null;
		}
		
		// check if users's friends already exist in HashMap, return friends if so.
		if (user._friends != null ) { 
			return user._friends;
		} 
		// else, query Friends and update HashMap to contain updated friends list
		String query = "select * from Friends where user_id1 = " 
				+ user_id + " or user_id2 = " + user_id; // since friendships are mutual, check both foreign keys.

		try {
			String res = this.openDBConnection();
			System.out.println(res);
			Statement st = _conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			ArrayList<Integer> friends = new ArrayList<Integer>(); // keep array list of user's friends
			while (rs.next()) {
				int friendId1 = rs.getInt("user_id1");
				int friendId2 = rs.getInt("user_id2");
				friends.add(friendId1 == user_id ? friendId2 : friendId1); // A friend is that who is not self in a friendship
			} 

			rs.close();
			st.close();
			
			// update the user's friendlist
			int[] userFriends = new int[friends.size()];
			for (int i = 0; i < friends.size(); i++) {
				userFriends[i] = friends.get(i);
			}
			user._friends = userFriends;
			return userFriends;
			
		} catch (SQLException s) {
			System.err.println("Registrar encountered an exception: " + s.toString());
		} catch (ClassNotFoundException c) {
			System.err.println("Registrar encountered an exception: " + c.toString());
		} finally {
			this.closeDBConnection();
		}
		return null;
	}

	
	/**
	 * returns the place_ids of all the places liked by the user with user_id
	 * @param user_id
	 * @return
	 */
	public int[] getLikes(int user_id) {
		
		User user = _users.get(user_id);
		if (user == null) {
			return null;
		}
		
		// check if users's likes already exist in HashMap, return likes if so.
		if (user._likes != null ) { 
			return user._likes;
		} 
		// else, query Friends and update HashMap to contain updated friends list
		String query = "select * from Likes where user_id = " + user_id;

		try {
			String res = this.openDBConnection();
			System.out.println(res);
			Statement st = _conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			ArrayList<Integer> likes = new ArrayList<Integer>(); // keep array list of user's friend
			while (rs.next()) {
				int placeId = rs.getInt("place_id");
				likes.add(placeId);
			}

			rs.close();
			st.close();
			
			// update the user's friendlist
			int[] userLikes = new int[likes.size()];
			for (int i = 0; i < likes.size(); i++) {
				userLikes[i] = likes.get(i);
			}
			user._likes = userLikes;
			return userLikes;
			
		} catch (SQLException s) {
			System.err.println("Registrar encountered an exception: " + s.toString());
		} catch (ClassNotFoundException c) {
			System.err.println("Registrar encountered an exception: " + c.toString());
		} finally {
			this.closeDBConnection();
		}
		return null;
	}

	
	/**
	 * returns an array of the form [lat,lon] representing the location
	 * of the place with place_id
	 * @param place_id
	 * @return
	 */
	public double[] getLocation(int place_id) {
		if (_places.containsKey(place_id)) {
			Place p = _places.get(place_id);
			double lat = p._lat;
			double lon = p._lon;
			double[] output = {lat, lon};
			return output;
		} else {
			return null;
		}
	}
	
	/**
	 * Returns true if the database contains a user with the specified userId
	 * @param userId the user's id
	 * @return
	 */
	public boolean hasUser(int userId) {
		return _users.containsKey(userId);
	}
	
	
	
	/**
	 * Inner class representing a User object
	 * @author tsakhuja
	 *
	 */
	private class User {
		private int _id;
		private String _firstName;
		private String _lastName;
		private double _lat;
		private double _lon;
		private int[] _friends;
		private int[] _likes;
		

		/**
		 * Constructor
		 * @param rs
		 * @throws SQLException
		 */
		public User(ResultSet rs) throws SQLException {
			_id = rs.getInt("user_id");
			_firstName = rs.getString("first_name");
			_lastName = rs.getString("last_name");
			_lat = rs.getDouble("latitude");
			_lon = rs.getDouble("longitude");
		}
	}
	
	/**
	 * Inner class representing a Place object
	 * @author tsakhuja
	 *
	 */
	public class Place {
		private int _id;
		private String _name;
		private int _typeId;
		private double _lat;
		private double _lon;
		
		public Place(int id, String name, int typeId, double lat, double lon) {
			_id = id;
			_name = name;
			_typeId= typeId;
			_lat = lat;
			_lon = lon;
		}
		
		public Place(ResultSet rs) throws SQLException {
			_id = rs.getInt("place_id");
			_name = rs.getString("place_name");
			_typeId = rs.getInt("type_id");
			_lat = rs.getDouble("latitude");
			_lon = rs.getDouble("longitude");
		}
	}
}
