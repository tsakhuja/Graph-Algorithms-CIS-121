package edu.upenn.cis.cis121.project;


import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;


public class NetworkAlgorithms {
	
	private DBWrapper db;
	
	/**
	 * Constructor
	 * @param dbUser
	 * @param dbPass
	 * @param dbSID
	 * @param dbHost
	 * @param port
	 */
	public NetworkAlgorithms(String dbUser, String dbPass, String dbSID, String dbHost, int port) {
		db = new DBWrapper(dbUser, dbPass, dbSID, dbHost, port);
	}
	
	/**
	 * Computes Bacon distance between two users. If either user does not exist in DB, throws
	 * exception
	 * @param user_id1
	 * @param user_id2
	 * @return
	 * @throws IllegalArgumentException if either user does not exist in DB
	 */
	public int distance(int userId1, int userId2) throws IllegalArgumentException {
		// check if db contains both users
		if (!db.hasUser(userId1) || !db.hasUser(userId2)) {
			throw new IllegalArgumentException();
		} else if (userId1 == userId2) {
			return 0; // Bacon distance between user and itself is 0
		} else{
			return baconBFS(userId1, userId2);
		}

	}
	
	private int baconBFS(int user1, int user2) {
		HashSet<Integer> marked = new HashSet<Integer>(); // keep Set of marked vertices
		HashMap<Integer, Integer> edgeTo = new HashMap<Integer, Integer>(); // keep Set of marked vertices
		LinkedList<Integer> queue = new LinkedList<Integer>();
		int start = user1; // starting point of traversal
		
		marked.add(start); // mark first node as seen
		queue.add(start); // add first node to queue
		
		while (!queue.isEmpty()) {
			int v = queue.remove(); // remove next vertex from queue
			for (int i : db.getFriends(v)) {
				if (!marked.contains(i)) { // for every unmarked adjacent vertex
					marked.add(i); // mark it as seen
					queue.add(i); // add it to queue
					edgeTo.put(i, v); // mark back edge in the form of prior vertex id
					if (i == user2) {
						// follow discovery edges from pt B to A to compute path length
						int cursor = user2;
						int length = 0;
						while(cursor != user1) {
							cursor = edgeTo.get(cursor);
							length++;
						}
						return length;
					}
				}
			}
		}
		return -1; // return -1 if no path found.
		
		
	}

}
