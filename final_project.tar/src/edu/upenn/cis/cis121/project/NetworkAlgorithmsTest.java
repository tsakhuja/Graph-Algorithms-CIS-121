package edu.upenn.cis.cis121.project;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class NetworkAlgorithmsTest {
	NetworkAlgorithms na;

	@Before
	public void setUp() throws Exception {
		na = new NetworkAlgorithms("tsakhuja", "chotu6718","CIS", "fling.seas.upenn.edu", 1521);
	}

	@Test
	public void testDistance() {
		assertTrue(na.distance(0, 0) == 0);
		//assertEquals(na.distance(-1, -1), null);
		//assertEquals(na.distance(0, -1), null);
		assertTrue(na.distance(0, 58) == 1);
		assertTrue(na.distance(58, 0) == 1);
		assertTrue(na.distance(0, 1) == 2);
		//assertTrue(na.distance(58, 1) == -1);
	}

}
